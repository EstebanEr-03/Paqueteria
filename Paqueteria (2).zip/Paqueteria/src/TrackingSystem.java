import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TrackingSystem {
    List<Package> packages=new ArrayList<>();
    List<Package> packagesPorCiudad=new ArrayList<>();

    public TrackingSystem() {
    }

    public void addPackage(Package package1){
        packages.add(package1);
    }
    /*public void ordenarListaPackage(Package package1){
        packages.add(package1);
    }*/
    public void removePackage(List<Package> listaRemover,String trackingNumberT){
        if (searchByTrackingNumberLineal(listaRemover,trackingNumberT)>=0){
            packages.remove(searchByTrackingNumberLineal(listaRemover,trackingNumberT));
        }
    }

    public int searchByTrackingNumberLineal(List<Package> listaBuscar, String trackingNumberT) {
        for (int j=0; j<listaBuscar.size(); j++){
            if (listaBuscar!= null && listaBuscar.size()>=0 && listaBuscar.get(j).getTrackingNumber().equals(trackingNumberT)){
                return j;
            }
        }
        return -1;
    }
    public Package searchByRecipientAddress(List<Package> listaBuscarPorRecipient, Address recipientAddr) {
        for (int i=0; i<listaBuscarPorRecipient.size(); i++){
            if (listaBuscarPorRecipient.get(i).getRecipientAddress().getStreet().equals(recipientAddr.getStreet()) && listaBuscarPorRecipient.get(i).getRecipientAddress().getCity().equals(recipientAddr.getCity()) && listaBuscarPorRecipient.get(i).getRecipientAddress().getState().equals(recipientAddr.getState()) && listaBuscarPorRecipient.get(i).getRecipientAddress().getZipCode().equals(recipientAddr.getZipCode())){
                return listaBuscarPorRecipient.get(i);
            }
        }
        return null;
    }
    public Package searchByAddress(List<Package> listaBuscarPorRecipient, Address recipientAddr) {
        for (int i=0; i<listaBuscarPorRecipient.size(); i++){
            if (listaBuscarPorRecipient.get(i).getSenderAddress().getStreet().equals(recipientAddr.getStreet()) && listaBuscarPorRecipient.get(i).getSenderAddress().getCity().equals(recipientAddr.getCity()) && listaBuscarPorRecipient.get(i).getSenderAddress().getState().equals(recipientAddr.getState()) && listaBuscarPorRecipient.get(i).getSenderAddress().getZipCode().equals(recipientAddr.getZipCode()) || listaBuscarPorRecipient.get(i).getRecipientAddress().getStreet().equals(recipientAddr.getStreet()) && listaBuscarPorRecipient.get(i).getRecipientAddress().getCity().equals(recipientAddr.getCity()) && listaBuscarPorRecipient.get(i).getRecipientAddress().getState().equals(recipientAddr.getState()) && listaBuscarPorRecipient.get(i).getRecipientAddress().getZipCode().equals(recipientAddr.getZipCode())){
                return listaBuscarPorRecipient.get(i);
            }
        }
        return null;
    }

    /*public static int searchBinary(ArrayList<Package> listaBuscarPorTrackingBinario, int targetTrackingNumberT) {
        int izquierda=0, derecha= listaBuscarPorTrackingBinario.size() -1;
        while (izquierda<=derecha){
            int numMedio=(derecha+izquierda)/2;
            if(targetTrackingNumberT==Integer.parseInt(listaBuscarPorTrackingBinario.get(numMedio).getTrackingNumber())){
                return numMedio;
            }else if(Integer.parseInt(listaBuscarPorTrackingBinario.get(numMedio).getTrackingNumber())<targetTrackingNumberT){
                izquierda=numMedio+1;
            }else{
                derecha=numMedio-1;
            }
        }
        return-1;
    }*/

    public  Package searchBinary(List<Package> listaBuscarPorTrackingBinario, int targetTrackingNumberT) {
        int izquierda=0, derecha= listaBuscarPorTrackingBinario.size() -1;
        while (izquierda<=derecha){
            int numMedio=(derecha+izquierda)/2;
            if(targetTrackingNumberT==Integer.parseInt(listaBuscarPorTrackingBinario.get(numMedio).getTrackingNumber())){
                return listaBuscarPorTrackingBinario.get(numMedio);
            }else if(Integer.parseInt(listaBuscarPorTrackingBinario.get(numMedio).getTrackingNumber())<targetTrackingNumberT){
                izquierda=numMedio+1;
            }else{
                derecha=numMedio-1;
            }
        }
        return null;
    }
    public List<Package> searchByCity (List<Package> listaBuscarPorCity, String city) {
        for (int a=0; a<listaBuscarPorCity.size(); a++){
            if (listaBuscarPorCity!=null && listaBuscarPorCity.size()>=0 && listaBuscarPorCity.get(a).getRecipientAddress().getCity().equals(city) || listaBuscarPorCity.get(a).getSenderAddress().getCity().equals(city)){

                packagesPorCiudad.add(listaBuscarPorCity.get(a));
            }
        }
        return packagesPorCiudad;
    }
}

